#include "device_motor.h"

//////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////         MOTOR          //////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * Initialises the motor pins
 * @param speed straight line speed
 * @param targetLeftDistance distance from left wall when assisted
 * @param timePerCell the time it takes the robot to cross cells at the given speed
 */
void Motor::init(int speed, float targetLeftDistance, float timePerCell, uint8_t wallDistanceThreshold)
{
  this->speed = speed;
  this->targetLeftDistance = targetLeftDistance;
  this->timePerCell = timePerCell;
  this->wallDistanceThreshold = wallDistanceThreshold;

  pinMode(PIN_MOTOR_A_PWM, OUTPUT);
  pinMode(PIN_MOTOR_B_PWM, OUTPUT);
  pinMode(PIN_MOTOR_A_IN, OUTPUT);
  pinMode(PIN_MOTOR_B_IN, OUTPUT);
  pinMode(PIN_MOTOR_STBY, OUTPUT);

  // Enable the gyroaccel

  this->ultrasonic = Ultrasonic();
  this->ultrasonic.init();

  this->servo = Servo();
  this->servo.init();

  this->gyroaccel = GyroAccel();
  this->gyroaccel.init();

  this->maze = Maze();
  this->maze.init(6, 6);
  this->robotRow = 0;
  this->robotCol = 3;
  this->direction = 0;

  int cell_width = 30; // 30x30 cm

  this->servo.setAngle(200);
  delay(50);
  float distLeft = this->ultrasonic.get_distance();
  bool wallLeft = distLeft <= this->wallDistanceThreshold;

  this->servo.setAngle(90);
  delay(50);
  float distStraight = this->ultrasonic.get_distance();
  bool wallStraight = distStraight <= this->wallDistanceThreshold;

  Cell currentCell = *maze.getCell(robotRow, robotCol);
  if (wallLeft)
  {
    currentCell.setLeftWall(true);
    this->maze.setCell(robotRow, robotCol, &currentCell);
  }
  if (wallStraight)
  {
    currentCell.setBottomWall(true);
    this->maze.setCell(robotRow, robotCol, &currentCell);
  }

  // Need to add this code at the end of the exploration phase
  // int goalRow, goalCol;
  // this->maze.getGoalCoord(&goalRow, &goalCol);
  // this->maze->floodFill(goalRow, goalCol, 1, 0);

  // Cell forwardCell = *maze.getCell(ceil(forwardDistance / cell_width), 0);
  // forwardCell.setTopWall(true);
  // maze.setCell(ceil(forwardDistance / cell_width), 0, &forwardCell);

  // Cell leftCell = *maze.getCell(0, ceil(leftDistance / cell_width));
  // leftCell.setLeftWall(true);
  // maze.setCell(0, ceil(leftDistance / cell_width), &leftCell);

  // Cell rightCell = *maze.getCell(0, ceil(rightDistance / cell_width));
  // rightCell.setRightWall(true);
  // maze.setCell(0, ceil(rightDistance / cell_width), &rightCell);
}

/**
 * Returns the GyroAccel object
 */
GyroAccel *Motor::getGyroAccel()
{
  return &this->gyroaccel;
}

/**
 * Clamps the input speed between the MIN_SPEED and MAX_SPEED
 */
uint8_t Motor::normaliseSpeed(uint8_t speed)
{
  speed = speed > MIN_SPEED ? speed : MIN_SPEED;
  speed = speed < MAX_SPEED ? speed : MAX_SPEED;
  return speed;
}

/**
 * Changes the right motor's direction and speed
 */
void Motor::rightMotor(uint8_t direction, uint8_t speed)
{
  digitalWrite(PIN_MOTOR_A_IN, direction);
  analogWrite(PIN_MOTOR_A_PWM, speed);
}

/**
 * Changes the left motor's direction and speed
 */
void Motor::leftMotor(uint8_t direction, uint8_t speed)
{
  digitalWrite(PIN_MOTOR_B_IN, direction);
  analogWrite(PIN_MOTOR_B_PWM, speed);
}

/**
 * One function for all simple movements.
 */
void Motor::move(Direction direction, int speed_left, int speed_right)
{
  // Enable both motors
  digitalWrite(PIN_MOTOR_STBY, HIGH);

  switch (direction)
  {
  case FORWARDS:
    this->forwards(speed_left, speed_right);
    break;
  case BACKWARDS:
    this->backwards(speed_left, speed_right);
    break;
  case RIGHT:
    this->right(speed_left, speed_right);
    break;
  case LEFT:
    this->left(speed_left, speed_right);
    break;
  case FORWARDS_RIGHT:
    this->forwardsRight(speed_left, speed_right);
    break;
  case FORWARDS_LEFT:
    this->forwardsLeft(speed_left, speed_right);
    break;
  case BACKWARDS_RIGHT:
    this->backwardsRight(speed_left, speed_right);
    break;
  case BACKWARDS_LEFT:
    this->backwardsLeft(speed_left, speed_right);
    break;
  default:
    // In case of an unhandled direction, stop the motors, log the error
    this->stop();
    Serial.println("ERROR: INVALID DIRECTION");
  }
}

void Motor::forwards(int speed_left, int speed_right)
{
  uint8_t leftDir = speed_left > 0 ? MOTOR_FORWARDS : MOTOR_BACKWARDS;
  uint8_t rightDir = speed_right > 0 ? MOTOR_FORWARDS : MOTOR_BACKWARDS;

  // Serial.print("LEFT SPEED: ");
  // Serial.println(speed_left);
  // Serial.print("RIGHT SPEED: ");
  // Serial.println(speed_right);
  // Serial.println();
  // Serial.println();
  // Serial.println();
  // Serial.println();
  this->rightMotor(leftDir, abs(speed_right));
  this->leftMotor(rightDir, abs(speed_left));
}

void Motor::backwards(uint8_t speed_left, uint8_t speed_right)
{
  this->rightMotor(MOTOR_BACKWARDS, speed_right);
  this->leftMotor(MOTOR_BACKWARDS, speed_left);
}

void Motor::right(uint8_t speed_left, uint8_t speed_right)
{
  this->rightMotor(MOTOR_BACKWARDS, speed_right);
  this->leftMotor(MOTOR_FORWARDS, speed_left);
}

void Motor::left(uint8_t speed_left, uint8_t speed_right)
{
  this->rightMotor(MOTOR_FORWARDS, speed_right);
  this->leftMotor(MOTOR_BACKWARDS, speed_left);
}

void Motor::forwardsRight(uint8_t speed_left, uint8_t speed_right)
{
  this->rightMotor(MOTOR_FORWARDS, speed_right / 2);
  this->leftMotor(MOTOR_FORWARDS, speed_left);
}

void Motor::forwardsLeft(uint8_t speed_left, uint8_t speed_right)
{
  this->rightMotor(MOTOR_FORWARDS, speed_right);
  this->leftMotor(MOTOR_FORWARDS, speed_left / 2);
}

void Motor::backwardsRight(uint8_t speed_left, uint8_t speed_right)
{
  this->rightMotor(MOTOR_BACKWARDS, speed_right / 2);
  this->leftMotor(MOTOR_BACKWARDS, speed_left);
}

void Motor::backwardsLeft(uint8_t speed_left, uint8_t speed_right)
{
  this->rightMotor(MOTOR_BACKWARDS, speed_right);
  this->leftMotor(MOTOR_BACKWARDS, speed_left / 2);
}

void Motor::stop()
{
  analogWrite(PIN_MOTOR_A_PWM, 0);
  analogWrite(PIN_MOTOR_B_PWM, 0);
  digitalWrite(PIN_MOTOR_STBY, LOW);
}

void Motor::turn(Direction direction, uint8_t speed, float *currentHeading)
{
  // Calculate new heading based on the current heading and direction to turn
  float timeToTurn;
  switch (direction)
  {
  case LEFT:
    this->direction = (this->direction - 1) % 4; // Modulo to wrap around the direction
    timeToTurn = 628;
    break;
  case RIGHT:
    this->direction = (this->direction + 1) % 4; // Modulo to wrap around the direction
    timeToTurn = 640;
    break;
  case BACKWARDS:
    break;
  }
  unsigned long currentTime = millis();
  while (millis() - currentTime < timeToTurn)
  {
    this->move(direction, 80, 80);
  }
  this->stop();
}

void Motor::updateSensor(void)
{
  float roll, pitch, yaw;
  this->gyroaccel.getRotation(&roll, &pitch, &yaw);
}

void Motor::sense(bool *wallLeft, bool *wallStraight, uint8_t *panicMode)
{
  this->servo.setAngle(200);
  delay(50);
  float distLeft = this->ultrasonic.get_distance();
  *wallLeft = distLeft <= this->wallDistanceThreshold;

  this->servo.setAngle(90);
  delay(50);
  float distStraight = this->ultrasonic.get_distance();
  *wallStraight = distStraight <= this->wallDistanceThreshold;

  if (distLeft < 6.5f)
  {
    *panicMode = *panicMode == 1 ? 2 : 1;
  }
  else if (distStraight < 2.5f)
  {
    *panicMode = *panicMode == 3 ? 4 : 3;
  }
  else
  {
    *panicMode = 0;
  }

  this->update_maze(*wallLeft, *wallStraight); // Update the maze based on the sensor readings

  this->servo.setAngle(200);
  delay(15);
}

// Updates the maze based on the current direction and sensor readings
void Motor::update_maze(bool wallLeft, bool wallStraight)
{
  Cell currentCell = *maze.getCell(this->robotRow, this->robotCol);
  switch (this->direction)
  {
  case 0:
    if (wallLeft)
    {
      currentCell.setRightWall(true);
    }
    if (wallStraight)
    {
      currentCell.setBottomWall(true);
    }
    break;
  case 1:

    if (wallLeft)
    {
      currentCell.setBottomWall(true);
    }
    if (wallStraight)
    {
      currentCell.setLeftWall(true);
    }
    break;
  case 2:
    if (wallLeft)
    {
      currentCell.setLeftWall(true);
    }
    if (wallStraight)
    {
      currentCell.setTopWall(true);
    }
    break;
  case 3:
    if (wallLeft)
    {
      currentCell.setTopWall(true);
    }
    if (wallStraight)
    {
      currentCell.setRightWall(true);
    }
    break;
  }
  maze.setCell(this->robotRow, this->robotCol, &currentCell);
}

// Updates the position of the robot based on the current direction
void Motor::update_position()
{
  switch (this->direction)
  {
  case 0:
    this->robotRow++;
    break;
  case 1:
    this->robotCol--;
    if (this->robotCol < 0)
    {
      this->robotCol += 1;
      this->maze.shiftLeft();
    }
    break;
  case 2:
    this->robotRow--;
    break;
  case 3:
    this->robotCol++;
    if (this->robotCol > this->maze.cols - 1)
    {
      this->robotCol -= 1;
      this->maze.shiftRight();
    }
    break;
  }
}

int Motor::getLessValueDirection()
{
  int minValue = 99;
  int targetRow = 0;
  int targetCol = 0;
  int targetDirection = 0;
  Cell currentCell = *maze.getCell(this->robotRow, this->robotCol);
  if (this->robotRow > 0 && !currentCell.getTopWall())
  {
    Cell topCell = *maze.getCell(this->robotRow - 1, this->robotCol);
    if (topCell.getVal() < minValue)
    {
      minValue = topCell.getVal();
      targetRow = this->robotRow - 1;
      targetCol = this->robotCol;
      targetDirection = 2;
    }
  }
  if (this->robotCol > 0 && !currentCell.getLeftWall())
  {
    Cell leftCell = *maze.getCell(this->robotRow, this->robotCol - 1);
    if (leftCell.getVal() < minValue)
    {
      minValue = leftCell.getVal();
      targetRow = this->robotRow;
      targetCol = this->robotCol - 1;
      targetDirection = 1;
    }
  }
  if (this->robotCol < this->maze.cols - 1 && !currentCell.getRightWall())
  {
    Cell rightCell = *maze.getCell(this->robotRow, this->robotCol + 1);
    if (rightCell.getVal() < minValue)
    {
      minValue = rightCell.getVal();
      targetRow = this->robotRow;
      targetCol = this->robotCol + 1;
      targetDirection = 3;
    }
  }
  if (this->robotRow < this->maze.rows - 1 && !currentCell.getBottomWall())
  {
    Cell bottomCell = *maze.getCell(this->robotRow + 1, this->robotCol);
    if (bottomCell.getVal() < minValue)
    {
      minValue = bottomCell.getVal();
      targetRow = this->robotRow + 1;
      targetCol = this->robotCol;
      targetDirection = 0;
    }
  }
  return targetDirection;
}

/**
 * Moves the robot in a straight line at a given speed
 * @param speed The speed at which to move (0-255 range)
 * @param targetYaw The target yaw angle of the robot
 */
void Motor::straightLine(uint8_t cells, bool assisted)
{
  this->update_position(); // Update the position of the robot

  // Look left
  this->servo.setAngle(200);

  // Get start time
  unsigned long ogTime = millis();
  unsigned long lastTime = ogTime;

  while (millis() - ogTime < this->timePerCell * cells)
  {
    // Get current error
    float distance = this->ultrasonic.get_distance();

    // If and when the left wall ends (e.g. a left turn is coming up in the cell we just moved into), switch to unassisted mode
    if (distance <= this->wallDistanceThreshold && millis() < ogTime + timePerCell / 2 && assisted)
    {
      this->straightAssisted(&lastTime, distance);
    }
    else
    {
      this->straightUnassisted(cells);
    }
  }

  // Braking phase, makes stopping smoother and more consistent
  this->backwards(50, 50);
  delay(50);
  this->stop();
}

void Motor::straightUnassisted(uint8_t cells)
{
  // 5 units of velocity added to the left to reduce the natural straying from the centre
  this->move(FORWARDS, this->speed + 5, this->speed);
}

// returns true while there is still a wall to track
bool Motor::straightAssisted(unsigned long *lastTime, uint16_t distance)
{
  // 1.8
  const float Kp = 8.0f; // Proportional gain
  const float Kd = 2.0f; // Derivative gain

  float CTE = 0.0f;
  float dCTE = 0.0f;
  float previousCTE = 0.0f;
  float CTEdifference = 0.0f;

  // Get current time and delta
  unsigned long currentTime = millis();
  const int delta = currentTime - *lastTime;
  *lastTime = currentTime;

  CTE = distance - this->targetLeftDistance;
  // Derivate of error
  CTEdifference = CTE - previousCTE;
  dCTE = CTEdifference / delta;

  // Calculate PD output
  int pdOutput = CTE * Kp + dCTE * Kd;
  // Adjust speeds and move accordingly
  this->move(FORWARDS, this->speed - pdOutput, this->speed + pdOutput);
  this->updateSensor();
  return true;
}