#include "device_ir.h"

//////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////      IR      //////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////

void IR::init()
{
    pinMode(PIN_IR_L, INPUT);
    pinMode(PIN_IR_M, INPUT);
    pinMode(PIN_IR_R, INPUT);
}

CellState IR::getCellState()
{
    int ir_value_left = analogRead(PIN_IR_L);
    int ir_value_middle = analogRead(PIN_IR_M);
    int ir_value_right = analogRead(PIN_IR_R);

    if (ir_value_left < 50) {
      return NORMAL;
    }
}

void IR::test()
{
    int ir_value_left = analogRead(PIN_IR_L);
    int ir_value_middle = analogRead(PIN_IR_M);
    int ir_value_right = analogRead(PIN_IR_R);
    Serial.print("IR_L=");
    Serial.print(ir_value_left);
    Serial.print("| IR_M=");
    Serial.print(ir_value_middle);
    Serial.print("| IR_R=");
    Serial.println(ir_value_right);
}