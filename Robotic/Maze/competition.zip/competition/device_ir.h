#include <Arduino.h>

enum CellState {
  NORMAL,
  START,
  GOAL
};

class IR
{
public:
    void init(void);
    void test(void);
    CellState getCellState();


private:
#define PIN_IR_L A2 // Left IR Sensor
#define PIN_IR_M A1 // Middle IR Sensor
#define PIN_IR_R A0 // Right IR Sensor
};